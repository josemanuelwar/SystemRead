<div>
<h1>Mensaje de SystemReady</h1>
<p><b>Nombre: </b>{{ $Nombre }}</p>
<p><b>Email: </b>{{ $correo }} </p>
<p><b>Telefono: </b>{{ $telefono }}</p>
<p><b>Mensaje: </b>{{ $mensage }}</p>
</div>