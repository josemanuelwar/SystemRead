<div>
<h1>Mensaje de SystemReady</h1>
<p><b>Nombre: </b><?php echo e($Nombre); ?></p>
<p><b>Email: </b><?php echo e($correo); ?> </p>
<p><b>Telefono: </b><?php echo e($telefono); ?></p>
<p><b>Mensaje: </b><?php echo e($mensage); ?></p>
</div><?php /**PATH C:\laragon\www\SystemRead\resources\views/correos/enviar.blade.php ENDPATH**/ ?>